/*,l
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automata;
import javax.swing.JOptionPane;
/**
 *
 * @author USER
 */
public class Seacrh extends javax.swing.JFrame {
int i;
char alpha;
    /**
     * Creates new form OEZY_DARAYANI
     */
    public Seacrh() {
        initComponents();
        setLocationRelativeTo(null);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regen   0operated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        KotakOutputNama = new java.awt.TextField();
        ButtonEnter = new javax.swing.JButton();
        loopNIM = new java.awt.TextField();
        Clear = new javax.swing.JButton();
        loopNama = new java.awt.TextField();
        KotakOutputNIM = new java.awt.TextField();
        KotakInNama = new javax.swing.JTextField();
        KotakInNIM = new javax.swing.JTextField();
        LabelInNama = new javax.swing.JLabel();
        LabelInNIM = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        KetNama = new java.awt.Label();
        KetNim = new java.awt.Label();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(24, 128, 128));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 372, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("X");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setForeground(new java.awt.Color(242, 242, 242));
        jPanel3.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N

        KotakOutputNama.setBackground(new java.awt.Color(0, 0, 0));
        KotakOutputNama.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        KotakOutputNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KotakOutputNamaActionPerformed(evt);
            }
        });

        ButtonEnter.setBackground(new java.awt.Color(0, 0, 0));
        ButtonEnter.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ButtonEnter.setForeground(new java.awt.Color(242, 242, 242));
        ButtonEnter.setText("Check");
        ButtonEnter.setBorderPainted(false);
        ButtonEnter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonEnterActionPerformed(evt);
            }
        });

        loopNIM.setBackground(new java.awt.Color(0, 0, 0));
        loopNIM.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        loopNIM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loopNIMActionPerformed(evt);
            }
        });

        Clear.setBackground(new java.awt.Color(0, 0, 0));
        Clear.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Clear.setForeground(new java.awt.Color(242, 242, 242));
        Clear.setText("Clear");
        Clear.setBorderPainted(false);
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        loopNama.setBackground(new java.awt.Color(0, 0, 0));
        loopNama.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        loopNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loopNamaActionPerformed(evt);
            }
        });

        KotakOutputNIM.setBackground(new java.awt.Color(0, 0, 0));
        KotakOutputNIM.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        KotakOutputNIM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KotakOutputNIMActionPerformed(evt);
            }
        });

        KotakInNama.setBackground(new java.awt.Color(0, 0, 0));
        KotakInNama.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        KotakInNama.setForeground(new java.awt.Color(255, 255, 255));
        KotakInNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KotakInNamaActionPerformed(evt);
            }
        });

        KotakInNIM.setBackground(new java.awt.Color(0, 0, 0));
        KotakInNIM.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        KotakInNIM.setForeground(new java.awt.Color(255, 255, 255));
        KotakInNIM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KotakInNIMActionPerformed(evt);
            }
        });

        LabelInNama.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LabelInNama.setForeground(new java.awt.Color(255, 255, 255));
        LabelInNama.setText("Nama:");

        LabelInNIM.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LabelInNIM.setForeground(new java.awt.Color(255, 255, 255));
        LabelInNIM.setText("NIM:");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));

        KetNama.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        KetNama.setForeground(new java.awt.Color(255, 255, 255));

        KetNim.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        KetNim.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Bookman Old Style", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(198, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(LabelInNama, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(228, 228, 228))
                        .addComponent(KotakInNama, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(LabelInNIM)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(KotakOutputNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonEnter)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(KotakOutputNama, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(KotakInNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Clear))))
                .addGap(51, 51, 51)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(KetNama, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(loopNama, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(209, 209, 209)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(loopNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KetNim, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(148, 148, 148)
                                .addComponent(jLabel3))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(LabelInNama)
                                    .addComponent(KotakInNama, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(LabelInNIM)
                                    .addComponent(KotakInNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(17, 17, 17)
                                .addComponent(ButtonEnter)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(loopNama, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(KotakOutputNama, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(34, 34, 34))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(KetNama, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(KotakOutputNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loopNIM, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KetNim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(Clear)
                .addGap(103, 103, 103))
        );

        KotakOutputNama.getAccessibleContext().setAccessibleName("");
        KotakInNama.getAccessibleContext().setAccessibleName("text nama");
        jLabel3.getAccessibleContext().setAccessibleName("status");

        jLabel5.setBackground(new java.awt.Color(0, 102, 102));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Implementasi FSA Pada Pemrograman");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 574, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
System.exit(0);             // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void KotakInNIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KotakInNIMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_KotakInNIMActionPerformed

    private void KotakInNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KotakInNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_KotakInNamaActionPerformed

    private void KotakOutputNIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KotakOutputNIMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_KotakOutputNIMActionPerformed

    private void loopNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loopNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_loopNamaActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        KotakInNama.setText("");
        KotakInNIM.setText("");
        KotakOutputNama.setText("");
        KotakOutputNIM.setText("");
        loopNama.setText("");
        loopNIM.setText("");
        KetNama.setText("");
        KetNim.setText("");
        jLabel2.setText("");
        jLabel8.setText("");
    }//GEN-LAST:event_ClearActionPerformed

    private void loopNIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loopNIMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_loopNIMActionPerformed

    private void ButtonEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonEnterActionPerformed
        String Nama = KotakInNama.getText();
        String NIM = KotakInNIM.getText();

        char [] karakter_nama = Nama.toCharArray();
        char [] karakter_nim = NIM.toCharArray();

        char[] namecatch = new char[Nama.length()];
        char[] nimcatch = new char[NIM.length()];

        try{
            String tangkap = "";
            String Ambil = "";

            for (int a = 0; a<Nama.length(); a++){
                namecatch[a] = karakter_nama[a];
                String EachFont = Character.toString(namecatch[a]);
                if(a != 0)
                tangkap = tangkap + karakter_nama[a-1];
                for(int i = 65; i <=123; i++){
                    this.setVisible(true);
                    KetNama.setText("");
                    alpha = (char) i;
                    loopNama.setText(""+alpha);//a
                    Thread.sleep(200);

                    if(alpha == karakter_nama[a])
                    {
                        Thread.sleep(50);
                        KetNama.setText("Karakter Diterima");
                        Thread.sleep(500);
                        loopNama.setText("");
                        KotakOutputNama.setText(""+ tangkap + alpha);
                        break;
                    }
                    else
                    {
                        KetNama.setText("Karakter Ditolak ");                      
                        Thread.sleep(200);
                        KetNama.setText("");
                        Thread.sleep(200);
                    }
                }
            }

            jLabel2.setText("String Valid");

            for (int a = 0; a<NIM.length(); a++){

                nimcatch[a] = karakter_nim[a];
                String eachnu = Character.toString(nimcatch[a]);
                if(a != 0)
                Ambil = Ambil + karakter_nim[a-1];
                for (int i = 48; i < 57; i++) {
                    this.setVisible(true);
                    alpha = (char) i;
                    KetNim.setText("");
                    loopNIM.setText(""+alpha);
                    Thread.sleep(400);

                    if(alpha == karakter_nim[a])
                    {
                        Thread.sleep(50);
                        KetNim.setText("Karakter Diterima");
                        Thread.sleep(500);
                        loopNIM.setText("");
                        KotakOutputNIM.setText(""+ Ambil + alpha);
                        break;
                    }
                    else
                    {
                        KetNim.setText("Karakter Ditolak ");
                        Thread.sleep(200);
                        KetNim.setText("");
                        Thread.sleep(200);
                    }

                }
            }
            jLabel8.setText("String Dikenali");
        }

        catch(InterruptedException ex){
            ex.printStackTrace();
        }
        //        String Nama = "";
        //        String NIM = "";
        ////        String Huruf = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        ////        String Angka = "0123456789";
        //        KotakOutputNama.setText("");
        //        KotakOutputNIM.setText("");

        //            Nama = KotakInNama.getText();
        //            NIM = KotakInNIM.getText();
        //            String M ="";
        //            for(int a=0;a<Nama.length();a++){
            //                if(a!=0)
            //                    M += Nama.charAt(a-1);
            //                for (i=0;i<Huruf.length();i++){
                //                    KotakOutputNama.setText(M);
                //                    txt5.setText(Character.toString(Huruf.charAt(i)));
                //                    this.setVisible(true);
                //                    Thread.sleep(1000);
                //                    if(Huruf.charAt(i)==Nama.charAt(a)){
                    //                        Thread.sleep(20);
                    //                        KotakOutputNama.setText(""+M+Character.toString(Huruf.charAt(i)));
                    //                        KetNama.setText("Karakter Diterima");
                    //                        Thread.sleep(900);
                    //                        break;
                    //                    }else{
                    //                        KetNama.setText("Karakter Ditolak");
                    //                    }
                //                }
            //            }KotakOutputNama.setText(Nama);
        //
        //        try{
            //            String N ="";
            //            for(int a=0;a<NIM.length();a++){
                //                if(a!=0) N += NIM.charAt(a-1);
                //                for (i=0;i<Angka.length();i++){
                    //                    KotakOutputNIM.setText(N);
                    //                    loopNIM.setText(Character.toString(Angka.charAt(i)));
                    //                    this.setVisible(true);
                    //                    Thread.sleep(1000);
                    //                    if(Angka.charAt(i)==NIM.charAt(a)) {
                        //                        KotakOutputNIM.setText(""+N+Character.toString(Angka.charAt(i)));
                        //                        KetNIM.setText("Karakter Diterima");
                        //                        Thread.sleep(900);
                        //                        break;
                        //                    }else{
                        //                        KetNIM.setText("Karakter Ditolak");
                        //                    }
                    //                }
                //            }KotakOutputNIM.setText(NIM);
            //        }
        //        catch (InterruptedException ex){ ex.printStackTrace();//do nothing
            //        }
    }//GEN-LAST:event_ButtonEnterActionPerformed

    private void KotakOutputNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KotakOutputNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_KotakOutputNamaActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seacrh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seacrh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seacrh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seacrh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seacrh().setVisible(true);
            
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonEnter;
    private javax.swing.JButton Clear;
    private java.awt.Label KetNama;
    private java.awt.Label KetNim;
    private javax.swing.JTextField KotakInNIM;
    private javax.swing.JTextField KotakInNama;
    private java.awt.TextField KotakOutputNIM;
    private java.awt.TextField KotakOutputNama;
    private javax.swing.JLabel LabelInNIM;
    private javax.swing.JLabel LabelInNama;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private java.awt.TextField loopNIM;
    private java.awt.TextField loopNama;
    // End of variables declaration//GEN-END:variables
}
